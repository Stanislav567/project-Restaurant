function ShowModal(modal) // Сюды прилетает айдишник элемента
{
    modal = document.getElementById(modal);
    modal.style.display = "flex";
}
function HideModal(modal) // Сюды прилетает айдишник элемента
{
    modal = document.getElementById(modal);
    modal.style.display = "none";
}
